import numpy as np
import matplotlib.pyplot as plt

File_out = np.load('out/output_data.npy')
File_in = np.load('out/input_data.npy')

out_mean_tr = File_out['mean_trajectory']
In_real_tr = File_in['real_robot_path']
Covs_tr = File_out['covariance_trajectory']

Dx = (Out_mean_tr-In_real_tr)

Covs = np.array([[3*Covs_tr[0,0,i], 3*covs_tr[1,1,i], 3*Covs_tr[2,2,i]] for i in range(Covs_tr.shape[2])])
Ew = Dx<=Covs

fig, (ax1, ax2, ax3) = plt.subplots(3,1, sharex=True)
ax1.plot(range(Covs.shape[0]), Covs[:,0], 'orange')
ax1.plot(range(Covs.shape[0]), -Covs[:,0], 'orange')
ax1.fill_between(range(Covs.shape[0]), Covs[:,0], -Covs[:,0],'orange', alpha=0.25)
ax1.plot(range(Dx.shape[0]), Dx[:,0], label='X')
ax1.set_title('for X')

ax2.plot(range(Dx.shape[0]), Dx[:,1], label='Y')
ax2.plot(range(Covs.shape[0]), Covs[:,1])
ax2.set_title('for Y')
